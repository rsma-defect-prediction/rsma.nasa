#' nasa_new1
#'
#' NASA datasets of software metrics for projects CM1, MW2, PC1, PC3 and PC4 (new versions).
#' The variables are all numeric, except for "Defective" which is a binary variable
#' (labeling an instance of code as defective or not).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_new1 <- nasa_new1[,2:39]
#' nasa_new1 <- nasa_new1 %>% mutate(Defective = ifelse(Defective=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: CM1, MW2, PC1, PC3, PC4}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_new1"

#' nasa_new2
#'
#' NASA datasets of software metrics for projects JM1 and KC1 (new versions).
#' The variables are all numeric, except for "label" which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_new2 <- nasa_new2[,2:23]
#' nasa_new2 <- nasa_new2 %>% mutate(label = ifelse(label=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: JM1, KC1}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{label}{Y if the variable is defective, N otherwise}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_new2"

#' nasa_new3
#'
#' NASA datasets of software metrics for projects KC3 and MC2 (new versions).
#' The variables are all numeric, except for "Defective" which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_new3 <- nasa_new3[,2:41]
#' nasa_new3 <- nasa_new3 %>% mutate(Defective = ifelse(Defective=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: KC3, MC2}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{GLOBAL_DATA_COMPLEXITY}{complexity of the global data reduced flow graph (count
#'   of paths through global data).}
#'   \item{GLOBAL_DATA_DENSITY}{global data complexity divided by cyclomatic complexity
#'   v(G).}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_new3"

#' nasa_new4
#'
#' NASA datasets of software metrics for projects MC1 and PC5 (new versions).
#' The variables are all numeric, except for "Defective" which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_new4 <- nasa_new4[,2:40]
#' nasa_new4 <- nasa_new4 %>% mutate(Defective = ifelse(Defective=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: MC1, PC5}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{GLOBAL_DATA_COMPLEXITY}{complexity of the global data reduced flow graph (count
#'   of paths through global data).}
#'   \item{GLOBAL_DATA_DENSITY}{global data complexity divided by cyclomatic complexity
#'   v(G).}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_new4"

#' nasa_new5
#'
#' NASA datasets of software metrics for project PC2 (new version).
#' The variables are all numeric, except for "Defective" which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_new5 <- nasa_new5[,2:38]
#' nasa_new5 <- nasa_new5 %>% mutate(Defective = ifelse(Defective=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: PC2}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_new5"

#' nasa_old1
#'
#' NASA datasets of software metrics for projects CM1, KC3, KC4, MC2, MW1, PC1,
#' PC2, PC3 and PC4 (old versions). All variables are numeric, except for "Defective"
#' which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: CM1, KC3, KC4, MC2, MW1, PC1,
#' PC2, PC3, PC4}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{GLOBAL_DATA_COMPLEXITY}{complexity of the global data reduced flow graph (count
#'   of paths through global data).}
#'   \item{GLOBAL_DATA_DENSITY}{global data complexity divided by cyclomatic complexity
#'   v(G).}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PATHOLOGICAL_COMPLEXITY}{Measures the degree to which a module contains extremely unstructured constructs. Also called pv(G).}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_old1"

#' nasa_old2
#'
#' NASA datasets of software metrics for projects JM1 and KC1 (old versions).
#' All variables are numeric, except for "label" which is a binary label.
#'
#' These metrics are used for software defect prediction (supervised learning
#' models). Clean with dplyr.
#'
#' @examples
#' nasa_old2 <- nasa_old2[,2:23]
#' nasa_old2 <- nasa_old2 %>% mutate(label = ifelse(label=="N", 0, 1))
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: JM1, KC1}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{label}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_old2"

#' nasa_old3
#'
#' Nasa datasets of software metrics for projects MC1 and PC5 (old versions).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @examples
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project: MC1, PC5}
#'   \item{LOC_BLANK}{number of blank lines of code}
#'   \item{BRANCH_COUNT}{number of logical branches.}
#'   \item{CALL_PAIRS}{executable calls between modules.}
#'   \item{LOC_CODE_AND_COMMENT}{sum of lines of code and lines of comment.}
#'   \item{LOC_COMMENTS}{number of lines of comment.}
#'   \item{CONDITION_COUNT}{number of conditions included in the module.}
#'   \item{CYCLOMATIC_COMPLEXITY}{McCabe’s cyclomatic complexity (maximum number of
#'   linearly independent paths through a program’s source code, computed from the control-flow
#'   graph). It’s the number of conditional branches in the control-flow graph. Can be described by
#'   the equation M = E − N + 2P, where E is the number of edges, N the number of nodes and P
#'   the number of connected components). Also called v(G).}
#'   \item{CYCLOMATIC_DENSITY}{cyclomatic complexity divided by the size of the system (in
#'   source statements).}
#'   \item{DECISION_COUNT}{number of decisions.}
#'   \item{DECISION_DENSITY}{number of decisions divided by the size of the system.}
#'   \item{DESIGN_COMPLEXITY}{number of paths that call something.}
#'   \item{DESIGN_DENSITY}{design complexity divided by cyclomatic complexity (total paths).}
#'   \item{EDGE_COUNT}{number of edges of the control-flow graph.}
#'   \item{ESSENTIAL_COMPLEXITY}{the sum of non reducible nodes plus one, plus one for each
#'   entry point after the first, plus one for each termination point after the first. Can be described
#'   by the equation ESSCOM = (NONREDUC +1)+(ENTRY PT −1)+(TERMPT −1). It’s
#'   basically the complexity of the reduced flow graph (from which the structured constructs have
#'                                                       been removed). Also called ev(G).}
#'   \item{ESSENTIAL_DENSITY}{it is the essential complexity with respect to the cyclomatic
#'   complexity. Described as (ev(G) − 1)/(v(G) − 1).}
#'   \item{LOC_EXECUTABLE}{lines of executable code.}
#'   \item{PARAMETER_COUNT}{number of parameters.}
#'   \item{GLOBAL_DATA_COMPLEXITY}{complexity of the global data reduced flow graph (count
#'   of paths through global data).}
#'   \item{GLOBAL_DATA_DENSITY}{global data complexity divided by cyclomatic complexity
#'   v(G).}
#'   \item{HALSTEAD_CONTENT}{a complexity measure that is computed in the same way regardless
#'   of the language used. Can be described by L · V , where L is the level and V is the volume of the
#'   module.}
#'   \item{HALSTEAD_DIFFICULTY}{error proneness of the program, computed as D = (UOP/2) ·
#'   (OD/UOD), where the elements of the equation are described further in this list.}
#'   \item{HALSTEAD_EFFORT}{it represents the mental effort required to develop or maintain a
#'   class. Described by E = D · V , where D is the difficulty and V the volume of the module.}
#'   \item{HALSTEAD_ERROR_EST}{estimated Halstead error.}
#'   \item{HALSTEAD_LENGTH}{total of all the lengths in the modules.}
#'   \item{HALSTEAD_LEVEL}{described by L = 1/D, where D is the difficulty of the module.}
#'   \item{HALSTEAD_PROG_TIME}{time (in seconds) to implement a program. Described by
#'   T = E/18, where E is the Halstead effort. The number 18 comes from empirical experiments.}
#'   \item{HALSTEAD_VOLUME}{total of all the volumes in the methods (the volume V is the
#'   information content of a program, measured in mathematical bits. V = length(program) ·
#'   log2(UOD + UOP)). The length of a program is computed as length(program) = OP + OD.}
#'   \item{MAINTENANCE_SEVERITY}{essential complexity divided by cyclomatic complexity.
#'   Described by ev(G)/v(G).}
#'   \item{MODIFIED_CONDITION_COUNT}{count for MC/DC (Modified Condition/Decision
#'   Coverage).}
#'   \item{MULTIPLE_CONDITION_COUNT}{Count for MCC (Multiple Condition Coverage).}
#'   \item{NODE_COUNT}{number of nodes in the control-flow graph.}
#'   \item{NORMALIZED_CYLOMATIC_COMPLEXITY}{normalized McCabe’s cyclomatic
#'   complexity}
#'   \item{NUM_OPERANDS}{number of operands OD.}
#'   \item{NUM_OPERATORS}{number of operators OP.}
#'   \item{NUM_UNIQUE_OPERANDS}{number of unique operands UOD.}
#'   \item{NUM_UNIQUE_OPERATORS}{number of unique operators UOP.}
#'   \item{NUMBER_OF_LINES}{number of lines.}
#'   \item{PERCENT_COMMENTS}{percentage of comments in the total lines of code.}
#'   \item{LOC_TOTAL}{total lines of code.}
#'   \item{Defective}{label. Y if the variable is defective, N otherwise.}
#' }
#'
#' @source \url{https://github.com/klainfo/NASADefectDataset}
"nasa_old3"
