#' NASA datasets for rsma
#'
#' This package contains 8 datasets for software defect prediction: \cr
#' \code{\link[rsma.nasa]{nasa_new1}} \cr
#' \code{\link[rsma.nasa]{nasa_new2}} \cr
#' \code{\link[rsma.nasa]{nasa_new3}} \cr
#' \code{\link[rsma.nasa]{nasa_new4}} \cr
#' \code{\link[rsma.nasa]{nasa_new5}} \cr
#' \code{\link[rsma.nasa]{nasa_old1}} \cr
#' \code{\link[rsma.nasa]{nasa_old2}} \cr
#' \code{\link[rsma.nasa]{nasa_old3}} \cr
#'
#' The software metrics in these datasets have been computed from 12 C/C++ projects:
#' \itemize{
#'   \item CM1: software for a spacecraft instrument.
#'   \item JM1: software to simulate ground predictions.
#'   \item KC1, KC3: storage management software.
#'   \item MC1, MC2, MW2: no information available.
#'   \item PC1, PC2, PC3, PC4, PC5: software for a satellite.
#' }
#'
#' @source
#' \link{https://github.com/klainfo/NASADefectDataset}.
#'
#' @references
#' Shepperd et al., Data Quality: Some Comments on the NASA Software Defect Datasets,
#' in IEEE Transactions on Software Engineering 39(9):1208-1215, September 2013.
#'
#' @docType package
#' @name rsma.nasa
NULL
